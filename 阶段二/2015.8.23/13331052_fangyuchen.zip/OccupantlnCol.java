public class OccupantlnCol{
    private Object occupant;
    private int col;
    public OccupantlnCol(Object o, int c) {
        occupant = o;
        col = c;
    }
    public Object getOccupantlnCol() {
    	return occupant;
    }
    public int getCol() {
        return col;
    }
    public void setObj(Object obj) {
    	occupant = obj;
    }
}
